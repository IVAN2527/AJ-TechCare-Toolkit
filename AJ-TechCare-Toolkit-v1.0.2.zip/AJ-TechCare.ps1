# A&J TechCare Toolkit v1.0
# Original portable Windows maintenance interface.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$AppName = 'A&J TechCare Toolkit'
$Version = '1.0.2'
$UpdateManifestUrl = 'https://raw.githubusercontent.com/IVAN2527/AJ-TechCare-Toolkit/main/update.json'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Reports = Join-Path $Root 'Reports'
New-Item -ItemType Directory -Path $Reports -Force | Out-Null
$SessionLog = Join-Path $Reports ("Session-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Administrator)) {
    $answer = [System.Windows.Forms.MessageBox]::Show(
        "This toolkit needs administrator permission for repairs.`r`nEsta herramienta necesita permiso de administrador para las reparaciones.",
        $AppName,
        [System.Windows.Forms.MessageBoxButtons]::OKCancel,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )
    if ($answer -eq [System.Windows.Forms.DialogResult]::OK) {
        Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $MyInvocation.MyCommand.Path))
    }
    exit
}

function Write-ToolkitLog([string]$Message) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $Message
    $script:LogBox.AppendText($line + [Environment]::NewLine)
    Add-Content -Path $SessionLog -Value $line -Encoding UTF8
    [System.Windows.Forms.Application]::DoEvents()
}

function Confirm-Action([string]$English, [string]$Spanish) {
    $result = [System.Windows.Forms.MessageBox]::Show(
        "$English`r`n`r`n$Spanish",
        'Confirm / Confirmar',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    return $result -eq [System.Windows.Forms.DialogResult]::Yes
}

function Invoke-ConsoleCommand([string]$Title, [string]$Command) {
    Write-ToolkitLog "START: $Title"
    try {
        $output = & cmd.exe /d /c $Command 2>&1
        foreach ($item in $output) { Write-ToolkitLog ([string]$item) }
        Write-ToolkitLog "FINISHED: $Title"
    } catch {
        Write-ToolkitLog "ERROR: $($_.Exception.Message)"
    }
}

function New-RestorePoint {
    if (-not (Confirm-Action 'Create a Windows restore point now?' 'Crear un punto de restauracion de Windows ahora?')) { return }
    Write-ToolkitLog 'Creating restore point / Creando punto de restauracion...'
    try {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
        Checkpoint-Computer -Description 'A&J TechCare Toolkit' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        Write-ToolkitLog 'Restore point created / Punto de restauracion creado.'
    } catch {
        Write-ToolkitLog "Restore point unavailable: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("Windows may limit restore points to one per 24 hours.`r`nWindows puede limitar los puntos de restauracion a uno cada 24 horas.",$AppName)
    }
}

function Repair-Network {
    if (-not (Confirm-Action 'Reset IP, DNS and Winsock? Internet may disconnect temporarily and a restart may be required.' 'Restablecer IP, DNS y Winsock? El internet puede desconectarse temporalmente y puede requerir reiniciar.')) { return }
    Invoke-ConsoleCommand 'Flush DNS' 'ipconfig /flushdns'
    Invoke-ConsoleCommand 'Register DNS' 'ipconfig /registerdns'
    Invoke-ConsoleCommand 'Release IP' 'ipconfig /release'
    Invoke-ConsoleCommand 'Renew IP' 'ipconfig /renew'
    Invoke-ConsoleCommand 'Reset Winsock' 'netsh winsock reset'
    Invoke-ConsoleCommand 'Reset TCP/IP' 'netsh int ip reset'
    [System.Windows.Forms.MessageBox]::Show("Network repair completed. Restart Windows.`r`nReparacion terminada. Reinicie Windows.",$AppName)
}

function Clear-TemporaryFiles {
    if (-not (Confirm-Action 'Delete temporary files older than 48 hours? Files currently in use will be skipped.' 'Eliminar archivos temporales de mas de 48 horas? Los archivos en uso seran omitidos.')) { return }
    $cutoff = (Get-Date).AddHours(-48)
    $targets = @($env:TEMP, (Join-Path $env:WINDIR 'Temp')) | Select-Object -Unique
    $deleted = 0
    foreach ($target in $targets) {
        Write-ToolkitLog "Cleaning: $target"
        Get-ChildItem -LiteralPath $target -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -lt $cutoff } |
            ForEach-Object {
                try { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction Stop; $deleted++ } catch { }
            }
    }
    Write-ToolkitLog "Temporary items removed: $deleted"
    [System.Windows.Forms.MessageBox]::Show("Temporary items removed: $deleted`r`nElementos temporales eliminados: $deleted",$AppName)
}

function Export-SystemReport {
    $path = Join-Path $Reports ("System-Report-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Write-ToolkitLog 'Creating system report / Creando reporte...'
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        $computer = Get-CimInstance Win32_ComputerSystem
        $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
        $bios = Get-CimInstance Win32_BIOS
        $lines = @(
            'A&J TECHCARE TOOLKIT - SYSTEM REPORT',
            ('Created: ' + (Get-Date)),
            ('Computer: ' + $env:COMPUTERNAME),
            ('Manufacturer: ' + $computer.Manufacturer),
            ('Model: ' + $computer.Model),
            ('Windows: ' + $os.Caption + ' ' + $os.Version),
            ('CPU: ' + $cpu.Name),
            ('Memory GB: ' + [math]::Round($computer.TotalPhysicalMemory / 1GB,2)),
            ('BIOS: ' + $bios.SMBIOSBIOSVersion),
            '', 'DISKS'
        )
        $lines += Get-Volume -ErrorAction SilentlyContinue | Format-Table DriveLetter,FileSystemLabel,FileSystem,HealthStatus,SizeRemaining,Size -AutoSize | Out-String
        $lines += '', 'NETWORK'
        $lines += Get-NetIPConfiguration -ErrorAction SilentlyContinue | Format-List | Out-String
        $lines | Out-File -FilePath $path -Encoding UTF8
        Write-ToolkitLog "Report saved: $path"
        Start-Process notepad.exe $path
    } catch { Write-ToolkitLog "Report error: $($_.Exception.Message)" }
}

function Invoke-WingetUpdates {
    if (-not (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show("Winget is not installed. Update App Installer from Microsoft Store.`r`nWinget no esta instalado. Actualice App Installer desde Microsoft Store.",$AppName)
        return
    }
    if (-not (Confirm-Action 'Update installed applications with Winget? Review the list before continuing.' 'Actualizar aplicaciones instaladas con Winget? Revise la lista antes de continuar.')) { return }
    Invoke-ConsoleCommand 'Winget application updates' 'winget upgrade --all --accept-source-agreements --accept-package-agreements'
}

function Invoke-DefenderScan {
    if (-not (Get-Command Start-MpScan -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show("Microsoft Defender commands are not available on this computer.`r`nLos comandos de Microsoft Defender no estan disponibles en esta computadora.",$AppName)
        return
    }
    if (-not (Confirm-Action 'Update Microsoft Defender and run a Quick Scan? Detected threats may be quarantined by Windows.' 'Actualizar Microsoft Defender y ejecutar un analisis rapido? Windows puede poner las amenazas detectadas en cuarentena.')) { return }
    Write-ToolkitLog 'Updating Microsoft Defender signatures / Actualizando definiciones de Defender...'
    try {
        Update-MpSignature -ErrorAction Stop | Out-Null
        Write-ToolkitLog 'Defender signatures updated / Definiciones actualizadas.'
    } catch {
        Write-ToolkitLog "Defender update warning: $($_.Exception.Message)"
    }
    Write-ToolkitLog 'START: Microsoft Defender Quick Scan'
    try {
        Start-MpScan -ScanType QuickScan -ErrorAction Stop
        $status = Get-MpComputerStatus -ErrorAction SilentlyContinue
        Write-ToolkitLog 'FINISHED: Microsoft Defender Quick Scan'
        if ($status) {
            Write-ToolkitLog ("Antivirus enabled: {0} | Real-time protection: {1}" -f $status.AntivirusEnabled,$status.RealTimeProtectionEnabled)
        }
        [System.Windows.Forms.MessageBox]::Show("Microsoft Defender scan completed. Review Windows Security for detected or quarantined threats.`r`nAnalisis completado. Revise Seguridad de Windows para ver amenazas detectadas o en cuarentena.",$AppName)
        Start-Process 'windowsdefender:' -ErrorAction SilentlyContinue
    } catch {
        Write-ToolkitLog "Defender scan error: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("The antivirus scan could not finish.`r`nEl analisis antivirus no pudo terminar.`r`n`r`n$($_.Exception.Message)",$AppName)
    }
}

function Invoke-BlueScreenCheck {
    $path = Join-Path $Reports ("Blue-Screen-Report-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Write-ToolkitLog 'Creating blue-screen diagnostic report / Creando reporte de pantalla azul...'
    try {
        $lines = @(
            'A&J TECHCARE TOOLKIT - BLUE SCREEN DIAGNOSTIC',
            ('Created: ' + (Get-Date)),
            ('Computer: ' + $env:COMPUTERNAME),
            '',
            'IMPORTANT: A blue screen can be caused by drivers, Windows files, memory, disk or hardware.',
            'IMPORTANTE: Una pantalla azul puede ser causada por controladores, Windows, memoria, disco o hardware.',
            '',
            'RECENT BUGCHECK AND UNEXPECTED SHUTDOWN EVENTS (30 DAYS)'
        )
        $events = Get-WinEvent -FilterHashtable @{LogName='System'; Id=@(41,1001); StartTime=(Get-Date).AddDays(-30)} -ErrorAction SilentlyContinue |
            Select-Object -First 30 TimeCreated,Id,ProviderName,Message
        if ($events) { $lines += ($events | Format-List | Out-String) } else { $lines += 'No matching events found.' }
        $lines += '', 'MINIDUMP FILES'
        $dumpPath = Join-Path $env:WINDIR 'Minidump'
        $dumps = Get-ChildItem -LiteralPath $dumpPath -Filter '*.dmp' -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 20 Name,LastWriteTime,Length
        if ($dumps) { $lines += ($dumps | Format-Table -AutoSize | Out-String) } else { $lines += 'No minidump files found.' }
        $lines += '', 'DEVICES WITH REPORTED ERRORS'
        $badDevices = Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue |
            Where-Object { $_.ConfigManagerErrorCode -ne 0 } |
            Select-Object Name,PNPDeviceID,ConfigManagerErrorCode
        if ($badDevices) { $lines += ($badDevices | Format-Table -AutoSize | Out-String) } else { $lines += 'No device errors reported by Windows.' }
        $lines | Out-File -FilePath $path -Encoding UTF8
        Write-ToolkitLog "Blue-screen report saved: $path"
        Start-Process notepad.exe $path
    } catch {
        Write-ToolkitLog "Blue-screen report error: $($_.Exception.Message)"
    }
    if (Confirm-Action 'Run safe Windows component repairs (DISM and SFC) now? This can take a long time and cannot repair failed hardware.' 'Ejecutar reparaciones seguras de Windows (DISM y SFC) ahora? Puede tardar bastante y no puede reparar hardware danado.') {
        Invoke-ConsoleCommand 'DISM RestoreHealth for blue-screen repair' 'DISM /Online /Cleanup-Image /RestoreHealth'
        Invoke-ConsoleCommand 'SFC Scan for blue-screen repair' 'sfc /scannow'
        [System.Windows.Forms.MessageBox]::Show("Windows component checks finished. Review the report and restart when ready. If blue screens continue, test memory, disk and drivers professionally.`r`nLas revisiones terminaron. Revise el reporte y reinicie cuando este preparado. Si continua la pantalla azul, revise memoria, disco y controladores profesionalmente.",$AppName)
    }
}

function Show-ToolkitUpdate {
    Check-AutomaticUpdate -ShowCurrent
}

function Check-AutomaticUpdate {
    param([switch]$ShowCurrent)
    Write-ToolkitLog 'Checking for toolkit updates / Buscando actualizaciones...'
    try {
        $manifest = Invoke-RestMethod -Uri $UpdateManifestUrl -UseBasicParsing -TimeoutSec 15
        if (-not $manifest.version -or -not $manifest.downloadUrl -or -not $manifest.sha256) {
            throw 'The update manifest is incomplete.'
        }
        $available = [version]$manifest.version
        $installed = [version]$Version
        if ($available -le $installed) {
            Write-ToolkitLog "Toolkit is current / La herramienta esta actualizada: v$Version"
            if ($ShowCurrent) {
                [System.Windows.Forms.MessageBox]::Show("You have the newest version: $Version`r`nTiene la version mas reciente: $Version",'A&J Toolkit Updates')
            }
            return
        }
        $choice = [System.Windows.Forms.MessageBox]::Show(
            "A verified update is available: v$available`r`nInstall it now? The toolkit will restart.`r`n`r`nHay una actualizacion verificada: v$available`r`nInstalarla ahora? La herramienta se reiniciara.",
            'A&J Toolkit Update / Actualizacion',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        if ($choice -ne [System.Windows.Forms.DialogResult]::Yes) { return }

        $updateRoot = Join-Path $env:TEMP ('AJ-TechCare-Update-' + [guid]::NewGuid().ToString('N'))
        $zipPath = Join-Path $updateRoot 'update.zip'
        $stagePath = Join-Path $updateRoot 'stage'
        New-Item -ItemType Directory -Path $stagePath -Force | Out-Null
        Write-ToolkitLog 'Downloading verified update / Descargando actualizacion verificada...'
        Invoke-WebRequest -Uri $manifest.downloadUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
        $actualHash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne ([string]$manifest.sha256).ToLowerInvariant()) {
            Remove-Item $updateRoot -Recurse -Force -ErrorAction SilentlyContinue
            throw 'Security check failed: SHA-256 does not match.'
        }
        Expand-Archive -Path $zipPath -DestinationPath $stagePath -Force
        $batchPath = Join-Path $updateRoot 'Apply-AJ-Update.cmd'
        $batch = @"
@echo off
timeout /t 3 /nobreak >nul
robocopy "$stagePath" "$Root" /E /R:2 /W:1 /XD Reports Backups >nul
start "" "$Root\Start-AJ-TechCare.cmd"
exit
"@
        Set-Content -Path $batchPath -Value $batch -Encoding ASCII
        Write-ToolkitLog 'Update verified. Restarting / Actualizacion verificada. Reiniciando...'
        Start-Process $batchPath
        $form.Close()
    } catch {
        Write-ToolkitLog "Update check unavailable: $($_.Exception.Message)"
        if ($ShowCurrent) {
            [System.Windows.Forms.MessageBox]::Show("Could not check updates right now.`r`nNo se pudieron revisar las actualizaciones ahora.`r`n`r`n$($_.Exception.Message)",'A&J Toolkit Updates')
        }
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "$AppName v$Version"
$form.Size = New-Object System.Drawing.Size(940,700)
$form.MinimumSize = New-Object System.Drawing.Size(940,700)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(14,18,24)
$form.ForeColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)

$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Top'; $header.Height = 110
$header.BackColor = [System.Drawing.Color]::FromArgb(7,27,51)
$form.Controls.Add($header)

$logoPath = Join-Path $Root 'Assets\AJ-TechCare-Logo.png'
if (Test-Path $logoPath) {
    $logo = New-Object System.Windows.Forms.PictureBox
    $logo.Location = New-Object System.Drawing.Point(12,10)
    $logo.Size = New-Object System.Drawing.Size(90,90)
    $logo.SizeMode = 'Zoom'
    $logo.Image = [System.Drawing.Image]::FromFile($logoPath)
    $header.Controls.Add($logo)
}

$title = New-Object System.Windows.Forms.Label
$title.Text = 'A&J TECHCARE TOOLKIT'
$title.Font = New-Object System.Drawing.Font('Segoe UI',24,[System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::White
$title.AutoSize = $true; $title.Location = New-Object System.Drawing.Point(120,17)
$header.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = 'PC Repair | Network Recovery | System Maintenance | 732-861-3005'
$subtitle.Font = New-Object System.Drawing.Font('Segoe UI',11)
$subtitle.ForeColor = [System.Drawing.Color]::FromArgb(255,193,7)
$subtitle.AutoSize = $true; $subtitle.Location = New-Object System.Drawing.Point(124,67)
$header.Controls.Add($subtitle)

$buttonPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$buttonPanel.Location = New-Object System.Drawing.Point(24,130)
$buttonPanel.Size = New-Object System.Drawing.Size(880,260)
$buttonPanel.WrapContents = $true
$buttonPanel.FlowDirection = 'LeftToRight'
$buttonPanel.AutoScroll = $true
$form.Controls.Add($buttonPanel)

function Add-ToolkitButton([string]$Text, [scriptblock]$Action, [System.Drawing.Color]$Color) {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Size = New-Object System.Drawing.Size(280,70)
    $button.Margin = New-Object System.Windows.Forms.Padding(6)
    $button.FlatStyle = 'Flat'; $button.FlatAppearance.BorderSize = 0
    $button.BackColor = $Color; $button.ForeColor = [System.Drawing.Color]::White
    $button.Font = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
    $button.Add_Click($Action)
    $buttonPanel.Controls.Add($button)
}

$blue = [System.Drawing.Color]::FromArgb(8,120,209)
$green = [System.Drawing.Color]::FromArgb(33,166,99)
$gold = [System.Drawing.Color]::FromArgb(190,135,0)

Add-ToolkitButton "Restore Point`nPunto de restauracion" { New-RestorePoint } $green
Add-ToolkitButton "Network Repair`nReparar internet y red" { Repair-Network } $blue
Add-ToolkitButton "System File Check (SFC)`nRevisar archivos Windows" { if (Confirm-Action 'Run SFC system scan?' 'Ejecutar revision SFC?') { Invoke-ConsoleCommand 'SFC Scan' 'sfc /scannow' } } $blue
Add-ToolkitButton "Windows Image Repair (DISM)`nReparar imagen Windows" { if (Confirm-Action 'Run DISM RestoreHealth?' 'Ejecutar DISM RestoreHealth?') { Invoke-ConsoleCommand 'DISM RestoreHealth' 'DISM /Online /Cleanup-Image /RestoreHealth' } } $blue
Add-ToolkitButton "Disk Check`nRevisar disco" { Invoke-ConsoleCommand 'CHKDSK Online Scan' 'chkdsk %SystemDrive% /scan' } $blue
Add-ToolkitButton "Safe Temp Cleanup`nLimpieza temporal segura" { Clear-TemporaryFiles } $gold
Add-ToolkitButton "System Report`nReporte del sistema" { Export-SystemReport } $green
Add-ToolkitButton "Update Applications`nActualizar aplicaciones" { Invoke-WingetUpdates } $green
Add-ToolkitButton "Windows Update`nActualizacion de Windows" { Start-Process 'ms-settings:windowsupdate' } $green
Add-ToolkitButton "Microsoft Defender Scan`nRevisar y eliminar virus" { Invoke-DefenderScan } ([System.Drawing.Color]::FromArgb(104,73,180))
Add-ToolkitButton "Blue Screen Check`nRevisar pantalla azul" { Invoke-BlueScreenCheck } ([System.Drawing.Color]::FromArgb(0,92,160))
Add-ToolkitButton "Toolkit Version & Updates`nVersion y actualizaciones" { Show-ToolkitUpdate } $gold
Add-ToolkitButton "Open Reports Folder`nAbrir carpeta de reportes" { Start-Process explorer.exe $Reports } $gold
Add-ToolkitButton "Restart Windows`nReiniciar Windows" { if (Confirm-Action 'Restart Windows now?' 'Reiniciar Windows ahora?') { Restart-Computer -Force } } ([System.Drawing.Color]::FromArgb(170,55,55))

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = 'Activity Log / Registro de actividad'
$logLabel.AutoSize = $true; $logLabel.Location = New-Object System.Drawing.Point(26,408)
$logLabel.Font = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
$form.Controls.Add($logLabel)

$script:LogBox = New-Object System.Windows.Forms.TextBox
$script:LogBox.Location = New-Object System.Drawing.Point(24,435)
$script:LogBox.Size = New-Object System.Drawing.Size(880,170)
$script:LogBox.Multiline = $true; $script:LogBox.ScrollBars = 'Vertical'; $script:LogBox.ReadOnly = $true
$script:LogBox.BackColor = [System.Drawing.Color]::FromArgb(25,31,40)
$script:LogBox.ForeColor = [System.Drawing.Color]::FromArgb(220,230,240)
$script:LogBox.Font = New-Object System.Drawing.Font('Consolas',9)
$form.Controls.Add($script:LogBox)

$footer = New-Object System.Windows.Forms.Label
$footer.Text = 'A&J Digital Services | Authorized computers only / Solo computadoras autorizadas | Support 732-861-3005'
$footer.AutoSize = $true; $footer.Location = New-Object System.Drawing.Point(25,620)
$footer.ForeColor = [System.Drawing.Color]::Silver
$form.Controls.Add($footer)

Write-ToolkitLog "$AppName v$Version started as Administrator."
Write-ToolkitLog 'Ready / Listo.'
$form.Add_Shown({ Check-AutomaticUpdate })
[void]$form.ShowDialog()
