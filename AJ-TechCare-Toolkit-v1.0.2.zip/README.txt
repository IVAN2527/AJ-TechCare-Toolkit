A&J TECHCARE TOOLKIT v1.0
PC Repair • Network Recovery • System Maintenance
Support / Soporte: 732-861-3005

VERSION 1.0.2
- Microsoft Defender virus scan / Analisis de virus con Microsoft Defender.
- Blue-screen diagnostic report and safe Windows repair.
- Reporte de pantalla azul y reparacion segura de Windows.
- Scroll bar for every option / Barra para ver todas las opciones.
- Proprietary no-copy license owned by A&J Digital Services.

ESPAÑOL
1. Descarga y extrae toda la carpeta en una USB.
2. En una computadora con Windows 10 u 11, abre la carpeta.
3. Haz clic derecho en Start-AJ-TechCare.cmd y selecciona Ejecutar como administrador.
4. Lee cada aviso antes de aceptar una reparación.
5. Algunos cambios de red requieren reiniciar la computadora.

ENGLISH
1. Download and extract the complete folder to a USB drive.
2. On a Windows 10 or Windows 11 PC, open the folder.
3. Right-click Start-AJ-TechCare.cmd and select Run as administrator.
4. Read each notice before approving a repair.
5. Some network changes require a computer restart.

AUTOMATIC UPDATES / ACTUALIZACIONES AUTOMÁTICAS
- The toolkit checks the official GitHub repository every time it starts.
- La herramienta revisa el repositorio oficial de GitHub cada vez que inicia.
- Every downloaded update is verified with SHA-256 before installation.
- Cada actualización se verifica con SHA-256 antes de instalarse.
- You must approve installation; updates are never installed silently.
- Usted debe aprobar la instalación; nunca se instala silenciosamente.

IMPORTANT / IMPORTANTE
- Create a restore point before major repairs when available.
- Cree un punto de restauración antes de reparaciones importantes cuando esté disponible.
- This tool uses official Windows commands. It does not bypass passwords, licenses, security, or access controls.
- Esta herramienta usa comandos oficiales de Windows. No evade contraseñas, licencias, seguridad ni controles de acceso.
- Use only on computers you own or are authorized to service.
- Úsela solamente en computadoras propias o que tenga autorización para reparar.
- Keep the full folder together on the USB. Reports are saved in the Reports folder.
- Mantenga toda la carpeta junta. Los reportes se guardan en Reports.

OWNERSHIP / PROPIEDAD
Copyright (c) 2026 A&J Digital Services. All rights reserved.
Copying, modification, resale or redistribution requires written permission.
Copiar, modificar, revender o redistribuir requiere permiso escrito.
