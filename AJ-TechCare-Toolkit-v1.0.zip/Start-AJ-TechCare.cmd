@echo off
setlocal
cd /d "%~dp0"
title A&J TechCare Toolkit v1.0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AJ-TechCare.ps1"
if errorlevel 1 (
  echo.
  echo A&J TechCare Toolkit could not start.
  echo No se pudo iniciar A&J TechCare Toolkit.
  pause
)
endlocal
